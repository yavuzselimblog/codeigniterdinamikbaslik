<?php 

 class Common_model extends CI_Model{

    public function get($where,$table){
        return $this->db->where($where)->get($table)->row();
    }

    public function getAll($where,$table){
        return $this->db->where($where)->get($table)->result();
    }

 }

?>