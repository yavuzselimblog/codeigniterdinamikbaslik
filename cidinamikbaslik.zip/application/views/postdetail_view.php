<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<?php if($page){ ?>
	<title><?php echo $page->title;?></title>
	<meta name="keywords" content="<?php echo $page->seokeyw;?>" />
	<meta name="description" content="<?php echo $page->seodesc;?>" />

	<meta property="og:title" content="<?php echo $page->title;?>" />
	<meta property="og:description" content="<?php echo $page->seodesc;?>" />
	<meta property="og:url" content="<?php echo base_url( $this->uri->uri_string() );?>" />
	<meta property="og:image" content="<?php echo $page->seoimg;?>" />

	<?php }else{ ?>

	<title>Welcome to CodeIgniter</title>
	<meta name="keywords" content="Welcome to CodeIgniter" />
	<meta name="description" content="Welcome to CodeIgniter" />	

	<?php } ?>

</head>
<body>

<div id="container">
	<h1><?php echo $postdetail->baslik;?></h1>
	<p><?php echo $postdetail->icerik;?></p>
</div>

</body>
</html>