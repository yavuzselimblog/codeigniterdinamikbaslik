<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<?php if($page){ ?>
	<title><?php echo $page->title;?></title>
	<meta name="keywords" content="<?php echo $page->seokeyw;?>" />
	<meta name="description" content="<?php echo $page->seodesc;?>" />

	<?php }else{ ?>

	<title>Welcome to CodeIgniter</title>
	<meta name="keywords" content="Welcome to CodeIgniter" />
	<meta name="description" content="Welcome to CodeIgniter" />	

	<?php } ?>

</head>
<body>

<div id="container">
	<h1>Welcome to CodeIgniter!</h1>
	<table border="1">
		<tr>
			<th>ID</th>
			<th>BAŞLIK</th>
			<th>İÇERİK</th>
		</tr>
		<?php 
			foreach($posts as $post){

				?>
				<tr>
					<td><?php echo $post->id;?></td>
					<td><a href="<?php echo base_url('home/detail/'.$post->seflink);?>"><?php echo $post->baslik;?></a></td>
					<td><?php echo $post->icerik;?></td>
				</tr>
				<?php
			
			}
		?>
	</table>
</div>

</body>
</html>