<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	public function index()
	{	

		$viewData = array(
			"posts" => $this->common_model->getAll([],'yazilar'),
			"page"  => (object) [
				'title'   => 'Ana Sayfa',
				'seokeyw' => 'Dinamik başlık,dinamik başlık dersi',
				'seodesc' => 'dinamik başlık dersi burada izlenir',
				'seoimg'  => 'logo.pnpg'
			]
		);

		$this->load->view('home_view',$viewData);
	}

	public function detail($sef){
		if(!$sef){
			redirect(base_url());
		}

		$query = $this->common_model->get(['seflink'=>$sef],'yazilar');
		if($query){

			$viewData = array(
				"postdetail" => $query,
				"page"       => (object)[

					'title'   => $query->baslik,
					'seokeyw' => $query->seokeyw,
					'seodesc' => $query->seodesc,
					'seoimg'  => $query->seoimg

				]
			);

			$this->load->view('postdetail_view',$viewData);

		}else{
			redirect(base_url());
		}
	}
}
